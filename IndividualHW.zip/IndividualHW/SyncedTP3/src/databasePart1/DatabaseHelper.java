package databasePart1;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


import application.Question;
import application.Questions;
import application.Answer;
import application.Answers;
import application.Review;  
import application.Message;

import application.User;

/**
 * The DatabaseHelper class is responsible for managing the connection to the database,
 * performing operations such as user registration, login validation, and handling invitation codes.
 */
public class DatabaseHelper {

	// JDBC driver name and database URL 
	static final String JDBC_DRIVER = "org.h2.Driver";   
	static final String DB_URL = "jdbc:h2:~/FoundationDatabase";  

	//  Database credentials 
	static final String USER = "sa"; 
	static final String PASS = ""; 

	private static Connection connection = null;
	private Statement statement = null; 
	//PreparedStatement pstmt


	public void connectToDatabase() throws SQLException {
		try {
			Class.forName(JDBC_DRIVER); // Load the JDBC driver
			System.out.println("Connecting to database...");
			connection = DriverManager.getConnection(DB_URL, USER, PASS);
			statement = connection.createStatement(); 
			 //You can use this command to clear the database and restart from fresh.
			//statement.execute("DROP ALL OBJECTS");

			createTables();  // Create the necessary tables if they don't exist
		} catch (ClassNotFoundException e) {
			System.err.println("JDBC Driver not found: " + e.getMessage());
		}
	}

	private void createTables() throws SQLException {
	    String userTable = "CREATE TABLE IF NOT EXISTS cse360users ("
	            + "id INT AUTO_INCREMENT PRIMARY KEY, "
	            + "userName VARCHAR(255) UNIQUE, "
	            + "password VARCHAR(255), "
	            + "role VARCHAR(20), "
	            + "fullName VARCHAR(255), "
	            + "email VARCHAR(255), "
	            + "one_time_password VARCHAR(255))";
	    statement.execute(userTable);
	    
	    // Create the invitation codes table
	    String invitationCodesTable = "CREATE TABLE IF NOT EXISTS InvitationCodes ("
	            + "code VARCHAR(10) PRIMARY KEY, "
	            + "isUsed BOOLEAN DEFAULT FALSE)";
	    statement.execute(invitationCodesTable);
	    
	    // Create the questions table
	    String questionsTable = "CREATE TABLE IF NOT EXISTS questions ("
	            + "id INT AUTO_INCREMENT PRIMARY KEY, "
	            + "userName VARCHAR(255), "
	            + "text TEXT)";
	    statement.execute(questionsTable);
	    //REVIEWERS TABLE FOR LATER
	    String trustedReviewersTable = "CREATE TABLE IF NOT EXISTS trusted_reviewers ("
	            + "studentUserName VARCHAR(255), "
	            + "reviewerUserName VARCHAR(255), "
	            + "weight INT CHECK(weight >= 1 AND weight <= 10), "
	            + "PRIMARY KEY (studentUserName, reviewerUserName), "
	            + "FOREIGN KEY (studentUserName) REFERENCES cse360users(userName), "
	            + "FOREIGN KEY (reviewerUserName) REFERENCES cse360users(userName))";
	    statement.execute(trustedReviewersTable);
	    // Create the replies table 
	    String repliesTable = "CREATE TABLE IF NOT EXISTS replies ("		
	            + "id INT AUTO_INCREMENT PRIMARY KEY, "
	            + "questionId INT, "
	            + "userName VARCHAR(255), "
	            + "replyText TEXT, "
	            + "isSelected BOOLEAN DEFAULT FALSE, "  // for answer deemed correct
	            + "FOREIGN KEY (questionId) REFERENCES questions(id) ON DELETE CASCADE)";
	    statement.execute(repliesTable);
	    
	    String reviewsTable = "CREATE TABLE IF NOT EXISTS reviews ("
	            + "id INT AUTO_INCREMENT PRIMARY KEY, "
	            + "reviewer_username VARCHAR(255) NOT NULL, "
	            + "question_id INT, "
	            + "answer_id INT, "
	            + "review_text TEXT, "
	            + "timestamp VARCHAR(255) "
	            + ")";
	        statement.execute(reviewsTable);
    
	    String messagesTable = "CREATE TABLE IF NOT EXISTS messages ("
	                + "id INT AUTO_INCREMENT PRIMARY KEY, "
	                + "sender VARCHAR(255), "
	                + "recipient VARCHAR(255), "
	                + "review_id INT, "
	                + "content TEXT, "
	                + "timestamp VARCHAR(255) "
	                + ")";
	            statement.execute(messagesTable);
	            
	         // Create the reviewer requests table
	     String reviewerRequestsTable = "CREATE TABLE IF NOT EXISTS reviewer_requests ("
	                + "student_username VARCHAR(255), "
	                + "request_date TIMESTAMP, "
	                + "PRIMARY KEY (student_username), "
	                + "FOREIGN KEY (student_username) REFERENCES cse360users(userName))";
	            statement.execute(reviewerRequestsTable);

	}
	public void insertDefaultAdmin() {
	    String checkSql = "SELECT COUNT(*) FROM cse360users WHERE userName = 'admin'";
	    String insertSql = "INSERT INTO cse360users (userName, password, role) VALUES ('admin', 'admin123', 'admin')";

	    try (PreparedStatement checkStmt = connection.prepareStatement(checkSql);
	         ResultSet rs = checkStmt.executeQuery()) {

	        if (rs.next() && rs.getInt(1) == 0) {
	            try (PreparedStatement insertStmt = connection.prepareStatement(insertSql)) {
	                insertStmt.executeUpdate();
	                System.out.println("Default admin inserted.");
	            }
	        } else {
	            System.out.println("Admin user already exists.");
	        }

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}




	// Check if the database is empty
	public boolean isDatabaseEmpty() throws SQLException {
		String query = "SELECT COUNT(*) AS count FROM cse360users";
		ResultSet resultSet = statement.executeQuery(query);
		if (resultSet.next()) {
			return resultSet.getInt("count") == 0;
		}
		return true;
	}

	// Registers a new user in the database.
	public void register(User user) throws SQLException {
		String insertUser = "INSERT INTO cse360users (userName, password, role) VALUES (?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(insertUser)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getRole());
			pstmt.executeUpdate();
		}
	}

	// Validates a user's login credentials.
	public boolean login(User user) throws SQLException {
		String query = "SELECT * FROM cse360users WHERE userName = ? AND password = ? AND role = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getRole());
			try (ResultSet rs = pstmt.executeQuery()) {
				return rs.next();
			}
		}
	}
	
	// Checks if a user already exists in the database based on their userName.
	public boolean doesUserExist(String userName) {
	    String query = "SELECT COUNT(*) FROM cse360users WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        
	        pstmt.setString(1, userName);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            // If the count is greater than 0, the user exists
	            return rs.getInt(1) > 0;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false; // If an error occurs, assume user doesn't exist
	}
	
	// Retrieves the role of a user from the database using their UserName.
	public String getUserRole(String userName) {
	    String query = "SELECT role FROM cse360users WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, userName);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getString("role"); // Return the role if user exists
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null; // If no user exists or an error occurs
	}

	
     	public String generateInvitationCode() {
	    String code = UUID.randomUUID().toString().substring(0, 4); //random 4-character code
	    String query = "INSERT INTO InvitationCodes (code) VALUES (?)";

	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return code;
	}
	
	// Validates an invitation code to check if it is unused.
	public boolean validateInvitationCode(String code) {
	    String query = "SELECT * FROM InvitationCodes WHERE code = ? AND isUsed = FALSE";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            markInvitationCodeAsUsed(code);
	            return true;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false;
	}
	
	// Marks the invitation code as used in the database.
	private void markInvitationCodeAsUsed(String code) {
	    String query = "UPDATE InvitationCodes SET isUsed = TRUE WHERE code = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	public List<User> getAllUsers() throws SQLException {
	    List<User> users = new ArrayList<>();
	    String query = "SELECT * FROM cse360users";  
	    try (Statement stmt = connection.createStatement()) {
	        ResultSet rs = stmt.executeQuery(query);
	        while (rs.next()) {
	            int id = rs.getInt("id");
	            String userName = rs.getString("userName");
	            String fullName = rs.getString("fullName"); 
	            String email = rs.getString("email"); 
	            String role = rs.getString("role");

	            users.add(new User(id, userName, fullName, email, role)); 
	        }
	    }
	    return users;
	}


	
	public List<User> getUserInfo() {
	    List<User> users = new ArrayList<>();
	    String query = "SELECT userName, fullName, email, role FROM cse360users";  

	    try (PreparedStatement pstmt = connection.prepareStatement(query);
	         ResultSet rs = pstmt.executeQuery()) {

	        while (rs.next()) {
	            // get user details from the ResultSet
	        	
	            String userName = rs.getString("userName");
	            String fullName = rs.getString("fullName");
	            String email = rs.getString("email");
	            String role = rs.getString("role");

	            
	            users.add(new User(userName, fullName, email, role));

	        }
	    } catch (SQLException e) {
	        e.printStackTrace();  
	    }

	    return users;
	}

	
	// In DatabaseHelper.java
	public void updateReply(int replyId, String userName, String newText) throws SQLException {
	    String updateSQL = "UPDATE replies SET replyText = ? WHERE id = ? AND userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(updateSQL)) {
	        pstmt.setString(1, newText);
	        pstmt.setInt(2, replyId);
	        pstmt.setString(3, userName);
	        int rowsUpdated = pstmt.executeUpdate();
	        if (rowsUpdated == 0) {
	            System.out.println("Edit failed: You can only edit your own replies.");
	        }
	    }
	}

	
	// Method to update user's full name and email in the database
    public void updateUserDetails(User user) throws SQLException {
        String query = "UPDATE cse360users SET fullName = ?, email = ? WHERE userName = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
        	
            pstmt.setString(1, user.getFullName());
            pstmt.setString(2, user.getEmail());
            pstmt.setString(3, user.getUserName());

            pstmt.executeUpdate();
        }
    }

	public void updateUserRole(String userName, String newRole) throws SQLException {
	    String query = "UPDATE cse360users SET role = ? WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	    	
	        pstmt.setString(1, newRole);
	        pstmt.setString(2, userName);
	        pstmt.executeUpdate();
	    }
	}

	public void removeUserRole(String userName) throws SQLException {
	    String query = "UPDATE cse360users SET role = NULL WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, userName);
	        pstmt.executeUpdate();
	    }
	}

	public int getAdminCount() throws SQLException {
	    String query = "SELECT COUNT(*) FROM cse360users WHERE role = 'admin'";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            return rs.getInt(1);
	        }
	    }
	    return 0;
	}
	
	public void changeUserRole(String userName, String newRole) throws SQLException {
	    String updateRoleSQL = "UPDATE cse360users SET role = ? WHERE userName = ?";
	    
	    try (PreparedStatement pstmt = connection.prepareStatement(updateRoleSQL)) {
	        pstmt.setString(1, newRole);
	        pstmt.setString(2, userName);
	        int rowsUpdated = pstmt.executeUpdate();
	        
	        if (rowsUpdated > 0) {
	            System.out.println("Role successfully updated for user: " + userName);
	        } else {
	            System.out.println("Role update failed. User not found.");
	            
	        }
	    }
	}
	
	//Deletes a user from the database 
		public boolean deleteUser(String userName) {							// 
		    String query = "DELETE FROM cse360users WHERE userName = ?";
		    try (PreparedStatement pstmt = connection.prepareStatement(query)) {	
		    	//delete USER 
		        pstmt.setString(1, userName);
		        int affectedRows = pstmt.executeUpdate();
		        return affectedRows > 0; //  true if a user was deleted
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		    return false; //  false if deletion failed
		}
	
	// Checks to make sure user is admin (for deletion purposes)
		public boolean isAdminUser(String userName) {
		    String query = "SELECT role FROM cse360users WHERE userName = ?";
		    try (PreparedStatement pstmt = connection.prepareStatement(query)) {							//CHECK FOR ADMIN USER
		        pstmt.setString(1, userName);
		        ResultSet rs = pstmt.executeQuery();
		        
		        while (rs.next()) {
		        	
		            if ("admin".equalsIgnoreCase(rs.getString("role"))) {
		                return true; //admin
		            }
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		    return false; //not an admin
		}
		// Store the OTP for the user
		public boolean setOneTimePassword(String userName, String oneTimePassword) {
		    String sql = "UPDATE cse360users SET one_time_password = ? WHERE userName = ?";
		    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
		        stmt.setString(1, oneTimePassword);
		        stmt.setString(2, userName);
		        int rowsAffected = stmt.executeUpdate();
		        return rowsAffected > 0; // Returns true if the user was found and OTP was set
		    } catch (SQLException e) {
		    	
		        e.printStackTrace();
		        return false; // Failure in case of SQL exception
		    }
		}


		// Get the OTP for a user (if it exists)
		public String getOneTimePassword(String userName) {
		    String sql = "SELECT one_time_password FROM cse360users WHERE userName = ?";
		    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
		        stmt.setString(1, userName);
		        ResultSet rs = stmt.executeQuery();
		        if (rs.next()) {
		            return rs.getString("one_time_password");
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		        
		    }
		    return null; // Return null if no OTP exists for the user
		}


		// Clear the OTP after it is used
		public void clearOneTimePassword(String userName) {
		    String sql = "UPDATE cse360users SET one_time_password = NULL WHERE userName = ?";
		    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
		        stmt.setString(1, userName);
		        stmt.executeUpdate();
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		}

		public void saveQuestion(String userName, String questionText) throws SQLException {
		    String insertSQL = "INSERT INTO questions (userName, text) VALUES (?, ?)";
		    try (PreparedStatement pstmt = connection.prepareStatement(insertSQL)) {
		        pstmt.setString(1, userName);
		        pstmt.setString(2, questionText);
		        pstmt.executeUpdate();
		    }
		}
		public List<Review> getAllReviews() {
		    List<Review> list = new ArrayList<>();
		    String sql = "SELECT * FROM reviews";
		    try (PreparedStatement pstmt = connection.prepareStatement(sql);
		         ResultSet rs = pstmt.executeQuery()) {
		        while (rs.next()) {
		            Review r = new Review(
		                rs.getInt("id"),
		                rs.getString("reviewer_username"),
		                rs.getInt("question_id"),
		                rs.getInt("answer_id"),
		                rs.getString("review_text")
		            );
		            list.add(r);
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		    return list;
		}

		
		// Insert a new review
		public int insertReview(String reviewerUsername, int questionId, int answerId, String reviewText, String timestamp) {
		    String sql = "INSERT INTO reviews (reviewer_username, question_id, answer_id, review_text, timestamp) VALUES (?, ?, ?, ?, ?)";
		    try (PreparedStatement pstmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
		        pstmt.setString(1, reviewerUsername);
		        pstmt.setInt(2, questionId);
		        pstmt.setInt(3, answerId);
		        pstmt.setString(4, reviewText);
		        pstmt.setString(5, timestamp);
		        pstmt.executeUpdate();
		        try (ResultSet rs = pstmt.getGeneratedKeys()) {
		            if (rs.next()) {
		                return rs.getInt(1);
		            }
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		    return -1;
		}
		
		// Retrieve users by userID 
		public boolean updateUserRole(int userId, String newRole) {
		    String query = "UPDATE cse360users SET role = ? WHERE id = ?";
		    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
		        pstmt.setString(1, newRole);
		        pstmt.setInt(2, userId);
		        return pstmt.executeUpdate() > 0;
		    } catch (SQLException e) {
		        e.printStackTrace();
		        return false;
		    }
		}


		// Retrieve reviews by reviewer
		public static List<Review> getReviewsByReviewer(String username) {
		    List<Review> list = new ArrayList<>();
		    String sql = "SELECT * FROM reviews WHERE reviewer_username = ?";
		    try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
		        pstmt.setString(1, username);
		        try (ResultSet rs = pstmt.executeQuery()) {
		            while (rs.next()) {
		                Review r = new Review(
		                    rs.getInt("id"),
		                    rs.getString("reviewer_username"),
		                    rs.getInt("question_id"),
		                    rs.getInt("answer_id"),
		                    rs.getString("review_text")
		                );
		                list.add(r);
		            }
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		    return list;
		}

		// Update a review
		public void updateReview(int reviewId, String newText) {
		    String sql = "UPDATE reviews SET review_text = ? WHERE id = ?";
		    try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
		        pstmt.setString(1, newText);
		        pstmt.setInt(2, reviewId);
		        pstmt.executeUpdate();
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		}

		// Delete a review
		public boolean deleteReview(int reviewId) {
		    String sql = "DELETE FROM reviews WHERE id = ?";
		    try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
		        pstmt.setInt(1, reviewId);
		        int rows = pstmt.executeUpdate();
		        return rows > 0; // return true if deletion occurred
		    } catch (SQLException e) {
		        e.printStackTrace();
		        return false;
		    }
		}
		
		public List<Review> getFlaggedReviews() {
		    List<Review> flagged = new ArrayList<>();
		    String sql = "SELECT * FROM reviews WHERE review_text LIKE '%FLAGGED%'"; // Change logic as needed

		    try (PreparedStatement pstmt = connection.prepareStatement(sql);
		         ResultSet rs = pstmt.executeQuery()) {
		        while (rs.next()) {
		            Review r = new Review(
		                rs.getInt("id"),
		                rs.getString("reviewer_username"),
		                rs.getInt("question_id"),
		                rs.getInt("answer_id"),
		                rs.getString("review_text")
		            );
		            flagged.add(r);
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }

		    return flagged;
		}
		
		



		
		public List<Question> getQuestionsByUser(String userName) throws SQLException {
		    List<Question> questions = new ArrayList<>();
		    String querySQL = "SELECT id, userName, text FROM questions WHERE userName = ?";
		    
		    try (PreparedStatement pstmt = connection.prepareStatement(querySQL)) {
		        pstmt.setString(1, userName);
		        ResultSet rs = pstmt.executeQuery();
		        
		        while (rs.next()) {
		            questions.add(new Question(rs.getInt("id"), rs.getString("userName"), rs.getString("text")));
		        }
		    }
		    
		    return questions;
		}

		
		public void updateQuestion(int questionId, String userName, String newText) throws SQLException {
		    String updateSQL = "UPDATE questions SET text = ? WHERE id = ? AND userName = ?";
		    try (PreparedStatement pstmt = connection.prepareStatement(updateSQL)) {
		        pstmt.setString(1, newText);
		        pstmt.setInt(2, questionId);
		        pstmt.setString(3, userName); 
		        int rowsUpdated = pstmt.executeUpdate();

		        if (rowsUpdated == 0) {
		            System.out.println("Edit failed: You can only edit your own questions.");
		        }
		    }
		}

		
		public Questions getAllQuestions() throws SQLException {
		    Questions questions = new Questions();
		    String querySQL = "SELECT id, userName, text FROM questions";

		    try (PreparedStatement pstmt = connection.prepareStatement(querySQL);
		         ResultSet rs = pstmt.executeQuery()) {

		        while (rs.next()) {
		            int questionId = rs.getInt("id");
		            String userName = rs.getString("userName");
		            String text = rs.getString("text");

		            Question question = new Question(questionId, userName, text);
		            Answers questionAnswers = new Answers(); 

		            Answers replies = getRepliesForQuestion(questionId);
		            for (Answer answer : replies.getAnswersForQuestion(questionId)) {
		                questionAnswers.addAnswer(answer);
		            }

		            question.getAnswers().getAnswersForQuestion(questionId).addAll(replies.getAnswersForQuestion(questionId));
		            questions.addQuestion(question);
		        }
		    }
		    return questions;
		}
		
		public List<Question> getAllQuestionsSortedByTrustedReviewers(String studentUserName) throws SQLException {
		    List<Question> questions = new ArrayList<>();
		    
		    String query = "SELECT q.id, q.userName, q.text, COALESCE(tr.weight, 0) AS weight "
		                 + "FROM questions q "
		                 + "LEFT JOIN trusted_reviewers tr ON q.userName = tr.reviewerUserName AND tr.studentUserName = ? "
		                 + "ORDER BY weight DESC, q.id ASC"; 
		    
		    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
		        pstmt.setString(1, studentUserName);
		        ResultSet rs = pstmt.executeQuery();

		        while (rs.next()) {
		            questions.add(new Question(rs.getInt("id"), rs.getString("userName"), rs.getString("text")));
		        }
		    }
		    
		    return questions;
		}

		
		
		public void saveReply(Answer answer) throws SQLException {
		    String insertSQL = "INSERT INTO replies (questionId, userName, replyText) VALUES (?, ?, ?)";
		    try (PreparedStatement pstmt = connection.prepareStatement(insertSQL)) {
		        pstmt.setInt(1, answer.getQuestionId());
		        pstmt.setString(2, answer.getUserName());  
		        pstmt.setString(3, answer.getText());
		        pstmt.executeUpdate();
		    }
		}



		
		public Answers getRepliesForQuestion(int questionId) throws SQLException {
		    Answers answers = new Answers(); 

		    String querySQL = "SELECT id, userName, replyText, isSelected FROM replies WHERE questionId = ?";
		    
		    try (PreparedStatement pstmt = connection.prepareStatement(querySQL)) {
		        pstmt.setInt(1, questionId);
		        ResultSet rs = pstmt.executeQuery();

		        while (rs.next()) {
		            Answer answer = new Answer(
		                rs.getInt("id"),
		                questionId,
		                rs.getString("userName"),
		                rs.getString("replyText")
		            );
		            answer.setSelected(rs.getBoolean("isSelected"));
		            answers.addAnswer(answer);
		        }
		    }
		    return answers; 
		}
		
		public void updateAnswerSelection(int answerId, boolean isSelected) throws SQLException {
		    String sql = "UPDATE replies SET isSelected = ? WHERE id = ?";
		    try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
		        pstmt.setBoolean(1, isSelected);
		        pstmt.setInt(2, answerId);
		        pstmt.executeUpdate();
		    }
		}



		
		
		public void deleteQuestion(int questionId, String userName) throws SQLException {
		    String query = "DELETE FROM questions WHERE id = ? AND userName = ?";
		    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
		        pstmt.setInt(1, questionId);
		        pstmt.setString(2, userName);
		        int rowsDeleted = pstmt.executeUpdate();
		        if (rowsDeleted > 0) {
		            System.out.println("Question deleted successfully.");
		        } else {
		            System.out.println("Failed to delete question. It may not belong to this user.");
		        }
		    }
		}
		
		// Retrieves reviews by answer ID
		public List<Review> getReviewsByAnswer(int answerId) {
		    List<Review> list = new ArrayList<>();
		    String sql = "SELECT * FROM reviews WHERE answer_id = ?";
		    try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
		        pstmt.setInt(1, answerId);
		        try (ResultSet rs = pstmt.executeQuery()) {
		            while (rs.next()) {
		                Review r = new Review(
		                    rs.getInt("id"),
		                    rs.getString("reviewer_username"),
		                    rs.getInt("question_id"),
		                    rs.getInt("answer_id"),
		                    rs.getString("review_text")
		                );
		                list.add(r);
		            }
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		    return list;
		}







		

				
		// Method to update the user's password
		public boolean updatePassword(String userName, String newPassword) throws SQLException {
		    String query = "UPDATE cse360users SET password = ? WHERE userName = ?";
		    
		    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
		        pstmt.setString(1, newPassword);  
		        pstmt.setString(2, userName);     

		        // Execute the update and return true if the password was updated
		        int rowsAffected = pstmt.executeUpdate();
		        return rowsAffected > 0;
		    } catch (SQLException e) {
		        e.printStackTrace();
		        return false;
		    }
		}
		
		public int insertMessage(String sender, String recipient, int reviewId, String content, String timestamp) {
	        String sql = "INSERT INTO messages (sender, recipient, review_id, content, timestamp) VALUES (?,?,?,?,?)";
	        try (PreparedStatement pstmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
	            pstmt.setString(1, sender);
	            pstmt.setString(2, recipient);
	            pstmt.setInt(3, reviewId);
	            pstmt.setString(4, content);
	            pstmt.setString(5, timestamp);
	            pstmt.executeUpdate();
	            try (ResultSet rs = pstmt.getGeneratedKeys()) {
	                if (rs.next()) {
	                    return rs.getInt(1);
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return -1;
	    }
		
		public List<Message> getMessagesForReview(int reviewId) {
	        List<Message> msgs = new ArrayList<>();
	        String sql = "SELECT * FROM messages WHERE review_id = ?";
	        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
	            pstmt.setInt(1, reviewId);
	            try (ResultSet rs = pstmt.executeQuery()) {
	                while (rs.next()) {
	                    Message m = new Message(
	                        rs.getString("sender"),
	                        rs.getString("recipient"),
	                        rs.getInt("review_id"),
	                        rs.getString("content")
	                    );
	                    // If you want to parse/store timestamp from DB:
	                    // String dbTimestamp = rs.getString("timestamp");
	                    msgs.add(m);
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return msgs;
	    }
		
		// Method to request to be a reviewer
		public void requestReviewerPermission(String studentUsername) throws SQLException {
		    // Insert the request into a "reviewer_requests" table
		    String query = "INSERT INTO reviewer_requests (student_username, request_date) VALUES (?, NOW())";
		    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
		        pstmt.setString(1, studentUsername);
		        pstmt.executeUpdate();
		    }
		}

		
		
		// Fetch students who have requested to be reviewers
		public List<String> getReviewerRequests() throws SQLException {
		    List<String> requests = new ArrayList<>();
		    String query = "SELECT student_username FROM reviewer_requests";
		    try (Statement stmt = connection.createStatement()) {
		        ResultSet rs = stmt.executeQuery(query);
		        while (rs.next()) {
		            requests.add(rs.getString("student_username"));
		        }
		    }
		    return requests;
		}

		// Method to approve a student as a reviewer
		public void approveReviewer(String userName) throws SQLException {
		    // You might want to do some checks before updating the reviewer status
		    String insertReviewer = "INSERT INTO trusted_reviewers (studentUserName, reviewerUserName, weight) "
		            + "VALUES (?, ?, ?)";  // Assuming you need to insert into trusted_reviewers table.

		    try (PreparedStatement pstmt = connection.prepareStatement(insertReviewer)) {
		        pstmt.setString(1, userName);  // The student's username
		        pstmt.setString(2, userName);  // The reviewer's username (same as student here)
		        pstmt.setInt(3, 5);  // A default weight (can be adjusted)

		        pstmt.executeUpdate();
		    } catch (SQLException e) {
		        e.printStackTrace();
		        throw new SQLException("Error approving reviewer.");
		    }
		}


		// Method to deny a reviewer request
		public void denyReviewer(String studentUsername) throws SQLException {
		    String query = "DELETE FROM reviewer_requests WHERE student_username = ?";
		    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
		        pstmt.setString(1, studentUsername);
		        pstmt.executeUpdate();
		    }
		}

		public void addReviewerTwo(String studentUserName, String reviewerUserName, int weight) {

			String query = "MERGE INTO trusted_reviewers USING (VALUES (?, ?, ?)) AS vals(studentUserName, reviewerUserName, weight) "
					+ // We first use a merge statement to update or insert the data to our trusted
						// reviewers table, then we call using to construct a temporary table that will
						// have "?" place holders for variables.
					"ON trusted_reviewers.studentUserName = vals.studentUserName AND trusted_reviewers.reviewerUserName = vals.reviewerUserName "
					+ // The ON condition is so that we can check if there is an instance of the same
						// username for the student and reviewer
					"WHEN MATCHED THEN UPDATE SET weight = vals.weight " + // when we find a match we can finally update the
																			// weight
					"WHEN NOT MATCHED THEN INSERT (studentUserName, reviewerUserName, weight) VALUES (?, ?, ?)"; 
			// if not matched then we can just insert a new row using our new given values

			// The connection block

			try (Connection currConnection = DriverManager.getConnection(DB_URL, USER, PASS);
					PreparedStatement statementFunctions = currConnection.prepareStatement(query)) {

				// Beginning updates to database
				statementFunctions.setString(1, studentUserName);
				statementFunctions.setString(2, reviewerUserName);
				statementFunctions.setInt(3, weight);

				// For needed Inserts
				statementFunctions.setString(4, studentUserName);
				statementFunctions.setString(5, reviewerUserName);
				statementFunctions.setInt(6, weight);

				statementFunctions.executeUpdate();
			} catch (SQLException e) {

				e.printStackTrace();
			}

		}


		public List<String> printAllTrustedReviewersTwo() {
			String query = "SELECT studentUserName, reviewerUserName, weight FROM trusted_reviewers";

			List<String> currentReviewersList = new ArrayList<>();

			try (Connection currConnection = DriverManager.getConnection(DB_URL, USER, PASS);
					PreparedStatement statementFunctions = currConnection.prepareStatement(query);
					ResultSet results = statementFunctions.executeQuery()) {

				while (results.next()) {
					String currStudentName = results.getString("studentUserName");
					String currReviewerName = results.getString("reviewerUserName");
					int currWeight = results.getInt("weight");
					currentReviewersList.add(
							currStudentName + " added reviewer " + currReviewerName + " with weight " + currWeight + ".");

				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return currentReviewersList;
		}

		public void updateWeightForReviewerT(String currStudent, String currReviewer, int updatedWeight) {
			// Calls for an update and will set weight to place holder of ? and a Where condition to find the exact student and review pair: 
			String query = "UPDATE trusted_reviewers " + "SET weight = ? "
					+ "WHERE studentUserName = ? AND reviewerUserName = ?";
			try (Connection currConnection = DriverManager.getConnection(DB_URL, USER, PASS);
					PreparedStatement statementFunctions = currConnection.prepareStatement(query)) {
				statementFunctions.setInt(1, updatedWeight);
				statementFunctions.setString(2, currStudent);
				statementFunctions.setString(3, currReviewer);
				
				// Attempts to update the query:
				int areasChanged = statementFunctions.executeUpdate();
				
				if (areasChanged > 0) {
					System.out.println("Weight was updated successfully!");
				}else {
					System.out.println("Weight undate has failed!");
				}
			
			} catch (SQLException e) {

				e.printStackTrace();
			}
			
		}
		
		// Method to update user's role to "reviewer"
		public void setUserRoleToReviewer(String userName) throws SQLException {
		    String updateRoleQuery = "UPDATE cse360users SET role = ? WHERE userName = ?";
		    
		    try (PreparedStatement pstmt = connection.prepareStatement(updateRoleQuery)) {
		        pstmt.setString(1, "reviewer");  // Update the role to "reviewer"
		        pstmt.setString(2, userName);    // The user whose role will be updated
		        pstmt.executeUpdate();
		    } catch (SQLException e) {
		        e.printStackTrace();
		        throw new SQLException("Error updating user role to reviewer.");
		    }
		}

	

				

	// Closes the database connection and statement.
	public void closeConnection() {
		try{ 
			if(statement!=null) statement.close(); 
		} catch(SQLException se2) { 
			se2.printStackTrace();
		} 
		try { 
			if(connection!=null) connection.close(); 
		} catch(SQLException se){ 
			se.printStackTrace(); 
		} 
	}

	
	public void addReviewer(String studentUserName, String reviewerUserName, int weight) {

		String query = "MERGE INTO trusted_reviewers USING (VALUES (?, ?, ?)) AS vals(studentUserName, reviewerUserName, weight) "
				+ // We first use a merge statement to update or insert the data to our trusted
					// reviewers table, then we call using to construct a temporary table that will
					// have "?" place holders for variables.
				"ON trusted_reviewers.studentUserName = vals.studentUserName AND trusted_reviewers.reviewerUserName = vals.reviewerUserName "
				+ // The ON condition is so that we can check if there is an instance of the same
					// username for the student and reviewer
				"WHEN MATCHED THEN UPDATE SET weight = vals.weight " + // when we find a match we can finally update the
																		// weight
				"WHEN NOT MATCHED THEN INSERT (studentUserName, reviewerUserName, weight) VALUES (?, ?, ?)"; // if not
																												// matched
																												// then
																												// we
																												// can
																												// just
																												// insert
																												// a new
																												// row
																												// using
																												// our
																												// new
																												// given
																												// values

		// The connection block

		try (Connection currConnection = DriverManager.getConnection(DB_URL, USER, PASS);
				PreparedStatement statementFunctions = currConnection.prepareStatement(query)) {

			// Beginning updates to database
			statementFunctions.setString(1, studentUserName);
			statementFunctions.setString(2, reviewerUserName);
			statementFunctions.setInt(3, weight);

			// For needed Inserts
			statementFunctions.setString(4, studentUserName);
			statementFunctions.setString(5, reviewerUserName);
			statementFunctions.setInt(6, weight);

			statementFunctions.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public void removeReviewer(String studentUserName, String reviewerUserName) {

		// query to try and delete a specific student
		String query = "DELETE FROM trusted_reviewers WHERE studentUserName = ? AND reviewerUserName = ?";

		try (Connection currConnection = DriverManager.getConnection(DB_URL, USER, PASS);
				PreparedStatement statementFunctions = currConnection.prepareStatement(query)) {

			// Beginning updates to database
			statementFunctions.setString(1, studentUserName);
			statementFunctions.setString(2, reviewerUserName);

			statementFunctions.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public List<String> printAllTrustedReviewers() {
		String query = "SELECT studentUserName, reviewerUserName, weight FROM trusted_reviewers";

		List<String> currentReviewersList = new ArrayList<>();

		try (Connection currConnection = DriverManager.getConnection(DB_URL, USER, PASS);
				PreparedStatement statementFunctions = currConnection.prepareStatement(query);
				ResultSet results = statementFunctions.executeQuery()) {

			while (results.next()) {
				String currStudentName = results.getString("studentUserName");
				String currReviewerName = results.getString("reviewerUserName");
				int currWeight = results.getInt("weight");
				currentReviewersList.add(
						currStudentName + " added reviewer " + currReviewerName + " with weight " + currWeight + ".");

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return currentReviewersList;
	}

	public void updateWeightForReviewer(String currStudent, String currReviewer, int updatedWeight) {
		// Calls for an update and will set weight to place holder of ? and a Where
		// condition to find the exact student and review pair:
		String query = "UPDATE trusted_reviewers " + "SET weight = ? "
				+ "WHERE studentUserName = ? AND reviewerUserName = ?";
		try (Connection currConnection = DriverManager.getConnection(DB_URL, USER, PASS);
				PreparedStatement statementFunctions = currConnection.prepareStatement(query)) {
			statementFunctions.setInt(1, updatedWeight);
			statementFunctions.setString(2, currStudent);
			statementFunctions.setString(3, currReviewer);

			int statementVerdict = statementFunctions.executeUpdate();

			if (statementVerdict > 0) {
				System.out.println("Successfully updated weight for " + currReviewer + " to " + updatedWeight);
			} else {
				System.out.println("Failed to update weight for " + currReviewer);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public static List<String> sortedReviewersList(String studentUser) {

		String query = "SELECT reviewerUserName, weight " + "FROM trusted_reviewers " + "WHERE studentUserName = ? "
				+ "ORDER BY weight DESC";
		List<String> sortedList = new ArrayList<>();
		try (Connection currConnection = DriverManager.getConnection(DB_URL, USER, PASS);
				PreparedStatement statementFunctions = currConnection.prepareStatement(query)) {

			statementFunctions.setString(1, studentUser);

			// Execute queries as needed:
			try (ResultSet results = statementFunctions.executeQuery()) {
				while (results.next()) {
					String currReviewerName = results.getString("reviewerUserName");
					int currWeight = results.getInt("weight");

					sortedList.add(currReviewerName + " Weight is: " + currWeight);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sortedList;
	}



	


}




















      
       
    
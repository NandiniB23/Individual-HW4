package application;

import databasePart1.DatabaseHelper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.util.List;

public class ReviewerHomePage {
    private final DatabaseHelper databaseHelper;
    private final User user;
    private final ReviewManager reviewManager;

    public ReviewerHomePage(DatabaseHelper databaseHelper, User user) {
        this.databaseHelper = databaseHelper;
        this.user = user;
        // Create a ReviewManager instance using the updated constructor
        this.reviewManager = new ReviewManager(this.databaseHelper);
    }

    public void show(Stage primaryStage) {
        VBox mainLayout = new VBox(10);
        mainLayout.setStyle("-fx-padding: 20; -fx-alignment: center;");
        
        // Title
        Label titleLabel = new Label("Reviewer Dashboard - " + user.getUserName());
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        mainLayout.getChildren().add(titleLabel);
        
        // ListView for reviews
        ListView<Review> reviewListView = new ListView<>();
        refreshReviewList(reviewListView);
        reviewListView.setPrefSize(500, 200);
        mainLayout.getChildren().add(reviewListView);
        
        // Buttons for review actions
        HBox buttonBox = new HBox(10);
        buttonBox.setStyle("-fx-alignment: center;");
        
        Button addReviewButton = new Button("Add Review");
        Button editReviewButton = new Button("Edit Review");
        Button deleteReviewButton = new Button("Delete Review");
        Button viewMessagesButton = new Button("View Messages");
        
        buttonBox.getChildren().addAll(addReviewButton, editReviewButton, deleteReviewButton, viewMessagesButton);
        mainLayout.getChildren().add(buttonBox);
        
        // Add Review action
        addReviewButton.setOnAction(e -> showAddReviewDialog(primaryStage, reviewListView));
        
        // Edit Review action
        editReviewButton.setOnAction(e -> {
            Review selected = reviewListView.getSelectionModel().getSelectedItem();
            if (selected != null) {
                showEditReviewDialog(primaryStage, selected, reviewListView);
            } else {
                showAlert("No Selection", "Please select a review to edit.");
            }
        });
        
        // Delete Review action
        deleteReviewButton.setOnAction(e -> {
            Review selected = reviewListView.getSelectionModel().getSelectedItem();
            if (selected != null) {
                reviewManager.deleteReviewById(selected.getId());  // ✅ Fixed
                refreshReviewList(reviewListView);
            } else {
                showAlert("No Selection", "Please select a review to delete.");
            }
        });

        
        // View Messages action (if you have a MessagePage, otherwise comment this out)
        viewMessagesButton.setOnAction(e -> {
            Review selected = reviewListView.getSelectionModel().getSelectedItem();
            if (selected != null) {
                new MessagePage(primaryStage, selected, reviewManager).show();
            } else {
                showAlert("No Selection", "Please select a review to view messages.");
            }
        });
        
        // Back button to return to user home page
        Button backButton = new Button("Back");
        backButton.setOnAction(e -> new UserHomePage(databaseHelper, user).show(primaryStage));
        mainLayout.getChildren().add(backButton);
        
        Scene scene = new Scene(mainLayout, 600, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Reviewer Dashboard");
        primaryStage.show();
    }

    // Refresh the ListView with current reviews by this reviewer
    private void refreshReviewList(ListView<Review> listView) {
        List<Review> reviews = reviewManager.getReviewsByReviewer(user.getUserName());
        ObservableList<Review> observableList = FXCollections.observableArrayList(reviews);
        listView.setItems(observableList);
        listView.setCellFactory(param -> new ListCell<Review>() {
            @Override
            protected void updateItem(Review item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    String display = "Review ID: " + item.getId()
                                   + " | QID: " + item.getQuestionId()
                                   + " | AID: " + item.getAnswerId() + "\n"
                                   + item.getReviewText();
                    setText(display);
                }
            }
        });
    }
    
    // Dialog for adding a new review
    private void showAddReviewDialog(Stage owner, ListView<Review> reviewListView) {
        Stage dialog = new Stage();
        dialog.initOwner(owner);
        dialog.setTitle("Add Review");
        VBox dialogLayout = new VBox(10);
        dialogLayout.setStyle("-fx-padding: 20; -fx-alignment: center;");
        
        TextField questionIdField = new TextField();
        questionIdField.setPromptText("Question ID (-1 if not applicable)");
        TextField answerIdField = new TextField();
        answerIdField.setPromptText("Answer ID (-1 if not applicable)");
        TextArea reviewTextArea = new TextArea();
        reviewTextArea.setPromptText("Enter review text");
        reviewTextArea.setPrefRowCount(4);
        
        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> {
            try {
                int questionId = Integer.parseInt(questionIdField.getText().trim());
                int answerId = Integer.parseInt(answerIdField.getText().trim());
                String reviewText = reviewTextArea.getText().trim();
                if (reviewText.isEmpty()) {
                    showAlert("Input Error", "Review text cannot be empty.");
                    return;
                }
                reviewManager.addReview(user.getUserName(), questionId, answerId, reviewText);
                refreshReviewList(reviewListView);
                dialog.close();
            } catch (NumberFormatException ex) {
                showAlert("Input Error", "Question ID and Answer ID must be integers.");
            }
        });
        
        dialogLayout.getChildren().addAll(new Label("Add New Review"),
                                          questionIdField,
                                          answerIdField,
                                          reviewTextArea,
                                          submitButton);
        Scene dialogScene = new Scene(dialogLayout, 400, 300);
        dialog.setScene(dialogScene);
        dialog.showAndWait();
    }
    
    // Dialog for editing an existing review
    private void showEditReviewDialog(Stage owner, Review review, ListView<Review> reviewListView) {
        Stage dialog = new Stage();
        dialog.initOwner(owner);
        dialog.setTitle("Edit Review");
        VBox dialogLayout = new VBox(10);
        dialogLayout.setStyle("-fx-padding: 20; -fx-alignment: center;");
        
        TextArea reviewTextArea = new TextArea(review.getReviewText());
        reviewTextArea.setPrefRowCount(4);
        
        Button updateButton = new Button("Update");
        updateButton.setOnAction(e -> {
            String newText = reviewTextArea.getText().trim();
            if (newText.isEmpty()) {
                showAlert("Input Error", "Review text cannot be empty.");
                return;
            }
            reviewManager.updateReview(review.getId(), newText);
            refreshReviewList(reviewListView);
            dialog.close();
        });
        
        dialogLayout.getChildren().addAll(new Label("Edit Review"),
                                          reviewTextArea,
                                          updateButton);
        Scene dialogScene = new Scene(dialogLayout, 400, 250);
        dialog.setScene(dialogScene);
        dialog.showAndWait();
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
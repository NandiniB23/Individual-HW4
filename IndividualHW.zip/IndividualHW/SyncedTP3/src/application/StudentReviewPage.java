package application;

import databasePart1.DatabaseHelper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.util.List;

public class StudentReviewPage {
    private final DatabaseHelper databaseHelper;
    private final User user;
    private final ReviewManager reviewManager;

    // ✅ CONSTRUCTOR MATCHING (DatabaseHelper, User)
    public StudentReviewPage(DatabaseHelper databaseHelper, User user) {
        this.databaseHelper = databaseHelper;
        this.user = user;
        this.reviewManager = new ReviewManager(databaseHelper);
    }

    // ✅ PUBLIC show(Stage) method
    public void show(Stage primaryStage) {
        VBox mainLayout = new VBox(10);
        mainLayout.setStyle("-fx-padding: 20; -fx-alignment: center;");

        Label titleLabel = new Label("Review Viewer - " + user.getUserName());
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        mainLayout.getChildren().add(titleLabel);

        List<Review> reviews = reviewManager.getAllReviews();  // Make sure this method exists
        ListView<Review> reviewListView = new ListView<>();
        ObservableList<Review> observableList = FXCollections.observableArrayList(reviews);
        reviewListView.setItems(observableList);
        reviewListView.setPrefSize(500, 200);
        reviewListView.setCellFactory(param -> new ListCell<Review>() {
            @Override
            protected void updateItem(Review item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    String display = "Review ID: " + item.getId()
                                   + " | QID: " + item.getQuestionId()
                                   + " | AID: " + item.getAnswerId() + "\n"
                                   + item.getReviewText();
                    setText(display);
                }
            }
        });

        mainLayout.getChildren().add(reviewListView);

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> new StudentHomePage(databaseHelper, user).show(primaryStage));
        mainLayout.getChildren().add(backButton);

        Scene scene = new Scene(mainLayout, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Student Review Viewer");
        primaryStage.show();
    }
}

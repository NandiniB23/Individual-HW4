// ReviewManager.java
package application;

import databasePart1.DatabaseHelper;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

public class ReviewManager {
    private DatabaseHelper db;
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public ReviewManager() {
        this.db = new DatabaseHelper();
    }

    public ReviewManager(DatabaseHelper db) {
        this.db = db;
    }
    

    public Review addReview(String reviewer, int questionId, int answerId, String text) {
        String timestamp = LocalDateTime.now().format(formatter);
        int id = db.insertReview(reviewer, questionId, answerId, text, timestamp);
        return new Review(id, reviewer, questionId, answerId, text);
    }

    public void updateReview(int reviewId, String newText) {
        db.updateReview(reviewId, newText);
    }

    public boolean deleteReviewById(int reviewId) {
        return db.deleteReview(reviewId);
    }

    public List<Review> getReviewsByReviewer(String username) {
        return db.getReviewsByReviewer(username);
    }

    public List<Review> getReviewsByAnswer(int answerId) {
        return db.getReviewsByAnswer(answerId);
    }

    public void sendMessage(Message m) {
        String timestamp = LocalDateTime.now().format(formatter);
        db.insertMessage(m.getSender(), m.getRecipient(), m.getReviewId(), m.getContent(), timestamp);
    }

    public List<Review> getAllReviews() {
        return db.getAllReviews();
    }

    public List<Message> getMessagesForReview(int reviewId) {
        return db.getMessagesForReview(reviewId);
    }

    public List<User> getAllUsers() {
        try {
            return db.getAllUsers();
        } catch (Exception e) {
            e.printStackTrace();
            return java.util.Collections.emptyList();
        }
    }

    public boolean updateUserRole(int userId, String newRole) {
        return db.updateUserRole(userId, newRole);
        
    }
    
    public List<Review> getFlaggedReviews() {
        return db.getFlaggedReviews();
    }

   
}
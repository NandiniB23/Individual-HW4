package application;

import java.time.LocalDateTime;

public class Review {
    private int id;
    private String reviewerUsername;
    private int questionId; // Use -1 if not for a question
    private int answerId;   // Use -1 if not for an answer
    private String reviewText;
    //private LocalDateTime timestamp;

    public Review(int id, String reviewerUsername, int questionId, int answerId, String reviewText) {
        this.id = id;
        this.reviewerUsername = reviewerUsername;
        this.questionId = questionId;
        this.answerId = answerId;
        this.reviewText = reviewText;
        //this.timestamp = LocalDateTime.now();
    }

    public int getId() { return id; }
    public String getReviewerUsername() { return reviewerUsername; }
    public int getQuestionId() { return questionId; }
    public int getAnswerId() { return answerId; }
    public String getReviewText() { return reviewText; }
    //public LocalDateTime getTimestamp() { return timestamp; }

    public void setReviewText(String reviewText) { this.reviewText = reviewText; }
}
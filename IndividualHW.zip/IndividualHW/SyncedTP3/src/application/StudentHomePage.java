package application;

import databasePart1.DatabaseHelper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.util.List;
import java.util.ArrayList;

public class StudentHomePage {
    private DatabaseHelper databaseHelper;
    private User user;
    private ReviewManager reviewManager;

    public StudentHomePage(DatabaseHelper db, User user) {
        this.databaseHelper = db;
        this.user = user;
        this.reviewManager = new ReviewManager(db);
    }

    public void show(Stage primaryStage) {
        VBox mainLayout = new VBox(10);
        mainLayout.setStyle("-fx-padding: 20; -fx-alignment: center;");

        // Title for the student dashboard
        Label titleLabel = new Label("Student Dashboard - " + user.getUserName());
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        mainLayout.getChildren().add(titleLabel);

        // ListView to display potential answers
        List<Answer> potentialAnswers = getPotentialAnswers();
        ListView<Answer> answerListView = new ListView<>();
        ObservableList<Answer> answerObservableList = FXCollections.observableArrayList(potentialAnswers);
        answerListView.setItems(answerObservableList);
        answerListView.setPrefSize(500, 200);
        mainLayout.getChildren().add(answerListView);

        // Button for the student to view reviews for the selected answer
        Button viewReviewsButton = new Button("View Reviews for Selected Answer");
        mainLayout.getChildren().add(viewReviewsButton);

        // TextArea to display reviews
        TextArea reviewsArea = new TextArea();
        reviewsArea.setEditable(false);
        reviewsArea.setPrefSize(500, 200);
        mainLayout.getChildren().add(reviewsArea);

        // Action: When the button is clicked, fetch and display reviews for the selected answer
        viewReviewsButton.setOnAction(e -> {
            Answer selectedAnswer = answerListView.getSelectionModel().getSelectedItem();
            if (selectedAnswer != null) {
                List<Review> reviews = reviewManager.getReviewsByAnswer(selectedAnswer.getId());
                StringBuilder sb = new StringBuilder();
                if (reviews.isEmpty()) {
                    sb.append("No reviews found for this answer.");
                } else {
                    for (Review r : reviews) {
                        sb.append("Reviewer: ").append(r.getReviewerUsername()).append("\n")
                          .append("Review: ").append(r.getReviewText()).append("\n\n");
                    }
                }
                reviewsArea.setText(sb.toString());
            } else {
                reviewsArea.setText("No answer selected.");
            }
        });

        // Back button
        Button backButton = new Button("Back");
        backButton.setOnAction(e -> new UserHomePage(databaseHelper, user).show(primaryStage));
        mainLayout.getChildren().add(backButton);

        // View all reviews (read-only page)
        Button viewAllReviewsButton = new Button("View All Reviews");
        viewAllReviewsButton.setOnAction(e -> new StudentReviewPage(databaseHelper, user).show(primaryStage));
        mainLayout.getChildren().add(viewAllReviewsButton);

        // Set the scene
        Scene scene = new Scene(mainLayout, 600, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Student Dashboard");
        primaryStage.show();
    }

    // Dummy method: Replace with your actual implementation to fetch potential answers.
    private List<Answer> getPotentialAnswers() {
        // Example: return databaseHelper.getPotentialAnswers();
        return new ArrayList<>();
    }
}

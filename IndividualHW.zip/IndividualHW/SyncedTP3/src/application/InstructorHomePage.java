package application;

	import databasePart1.DatabaseHelper;
	import javafx.scene.Scene;
	import javafx.scene.control.*;
	import javafx.scene.layout.HBox;
	import javafx.scene.layout.VBox;
	import javafx.stage.Stage;
	import java.sql.SQLException;
	import java.util.List;

public class InstructorHomePage {
	

	    private DatabaseHelper databaseHelper;
	    private User user;
	    private Questions questionList;
	    private Question selectedQuestion;  

	    // This ListView holds VBoxes, each representing a single question + replies
	    private ListView<VBox> questionListView;

	    public InstructorHomePage(DatabaseHelper databaseHelper, User user) {
	        this.databaseHelper = databaseHelper;
	        this.user = user;
	        this.questionList = new Questions();
	        this.selectedQuestion = null; 
	    
	    }
	    
	    private void showAlert(String title, String message) {
	        Alert alert = new Alert(Alert.AlertType.INFORMATION);
	        alert.setTitle(title);
	        alert.setHeaderText(null);
	        alert.setContentText(message);
	        alert.showAndWait();
	    }

	    
	    private void showReviewerRequests() {
	        try {
	            List<String> students = databaseHelper.getReviewerRequests();
	            ListView<String> reviewerListView = new ListView<>();
	            reviewerListView.getItems().addAll(students);

	            Button approveButton = new Button("Approve");
	            Button denyButton = new Button("Deny");

	            approveButton.setOnAction(e -> {
	                String selectedStudent = reviewerListView.getSelectionModel().getSelectedItem();
	                if (selectedStudent != null) {
	                    try {
	                        // Update the user's role to "reviewer"
	                        databaseHelper.setUserRoleToReviewer(selectedStudent);
	                        
	                        // Approve the student as a reviewer in your existing logic
	                        databaseHelper.approveReviewer(selectedStudent);
	                        
	                        // Show confirmation alert
	                        showAlert("Approved", selectedStudent + " is now a reviewer.");
	                        
	                        // Remove the student from the list
	                        reviewerListView.getItems().remove(selectedStudent);
	                    } catch (SQLException ex) {
	                        ex.printStackTrace();
	                        showAlert("Error", "Unable to approve student. Please try again.");
	                    }
	                }
	            });


	            denyButton.setOnAction(e -> {
	                String selectedStudent = reviewerListView.getSelectionModel().getSelectedItem();
	                if (selectedStudent != null) {
	                    try {
	                        databaseHelper.denyReviewer(selectedStudent);
	                        showAlert("Denied", selectedStudent + "'s request has been denied.");
	                        reviewerListView.getItems().remove(selectedStudent);
	                    } catch (SQLException ex) {
	                        ex.printStackTrace();
	                        showAlert("Error", "Unable to deny request. Please try again.");
	                    }
	                }
	            });

	            VBox reviewLayout = new VBox(10);
	            reviewLayout.getChildren().addAll(
	                new Label("Students requesting to be reviewers:"),
	                reviewerListView,
	                approveButton,
	                denyButton
	            );

	            Stage reviewStage = new Stage();
	            reviewStage.setTitle("Review Requests");
	            reviewStage.setScene(new Scene(reviewLayout, 400, 300));
	            reviewStage.show();
	        } catch (SQLException e) {
	            e.printStackTrace();
	            showAlert("Error", "Unable to load review requests. Please try again.");
	        }
	    }

	   
	    public void show(Stage primaryStage) {
	        VBox layout = new VBox(5);
	        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");
	        
	        // Display a welcome message with the user's username
	        Label userLabel = new Label("Welcome, " + user.getUserName() + "!");
	        userLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
	        
	        // Add more functionality for User Page here
	        Button requestReviewerButton = new Button("Request to be a Reviewer");
	        requestReviewerButton.setOnAction(e -> {
	            try {
	                // Send a request to the database
	                databaseHelper.requestReviewerPermission(user.getUserName());
	                showAlert("Request Sent", "Your request to be a reviewer has been submitted.");
	            } catch (SQLException ex) {
	                ex.printStackTrace();
	                showAlert("Error", "Unable to submit request. Please try again.");
	            }
	        });
	        
	        Button reviewRequestsButton = new Button("Review Reviewer Requests");
	        reviewRequestsButton.setOnAction(e -> {
	            showReviewerRequests();
	        });
	        
	        
	        

	        layout.getChildren().add(userLabel);
	        
	        layout.getChildren().add(reviewRequestsButton);  // Add the review button



	        Scene userScene = new Scene(layout, 800, 400);
	        primaryStage.setScene(userScene);
	        primaryStage.setTitle("Instructor Page");
	    }
	
	    
}

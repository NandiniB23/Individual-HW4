package application;

public class User {
    private int id;
    private String userName;
    private String password;
    private String role;
    private String fullName;
    private String email;

    // ✅ Full Constructor including ID
    public User(int id, String userName, String fullName, String email, String role) {
        this.id = id;
        this.userName = userName;
        this.fullName = fullName;
        this.email = email;
        this.role = role;
    }

    // ✅ Constructor without ID (e.g., for registration)
    public User(String userName, String fullName, String email, String role) {
        this.userName = userName;
        this.fullName = fullName;
        this.email = email;
        this.role = role;
    }

    // ✅ Constructor for login/auth cases
    public User(String userName, String password, String role) {
        this.userName = userName;
        this.password = password;
        this.role = role;
    }

    // ✅ Getters & Setters
    public int getId() {
        return id;
    }

    public String getUserName() {
        return userName;
    }

    public String getUsername() {
        return userName; // alias for compatibility
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}

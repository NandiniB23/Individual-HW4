package application;

public class Message {
    private String sender;
    private String recipient;
    private int reviewId;
    private String content;

    public Message(String sender, String recipient, int reviewId, String content) {
        this.sender = sender;
        this.recipient = recipient;
        this.reviewId = reviewId;
        this.content = content;
    }

    public String getSender() {
        return sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public int getReviewId() {
        return reviewId;
    }

    public String getContent() {
        return content;
    }
}

package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.util.List;

public class MessagePage {
    private final Stage owner;
    private final Review review;
    private final ReviewManager reviewManager;

    public MessagePage(Stage owner, Review review, ReviewManager reviewManager) {
        this.owner = owner;
        this.review = review;
        this.reviewManager = reviewManager;
    }

    public void show() {
        // Create a new Stage for the message UI
        Stage messageStage = new Stage();
        messageStage.initOwner(owner);
        messageStage.setTitle("Messages for Review ID: " + review.getId());

        VBox layout = new VBox(10);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");

        // Title label
        Label titleLabel = new Label("Messages for Review: " + review.getReviewText());
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        layout.getChildren().add(titleLabel);

        // ListView to display messages
        ListView<Message> messageListView = new ListView<>();
        refreshMessageList(messageListView);
        messageListView.setPrefSize(500, 200);
        layout.getChildren().add(messageListView);

        // Input field for sending new messages
        TextField messageField = new TextField();
        messageField.setPromptText("Enter your message here...");
        messageField.setPrefWidth(400);

        Button sendButton = new Button("Send");
        sendButton.setOnAction(e -> {
            String content = messageField.getText().trim();
            if (!content.isEmpty()) {
                // Example: The "sender" is the reviewer, "recipient" could be the "author" or something else
                Message newMsg = new Message(
                    review.getReviewerUsername(), // sender
                    "author",                      // recipient
                    review.getId(),
                    content
                );
                reviewManager.sendMessage(newMsg);
                messageField.clear();
                refreshMessageList(messageListView);
            }
        });

        HBox inputBox = new HBox(10, messageField, sendButton);
        inputBox.setStyle("-fx-alignment: center;");
        layout.getChildren().add(inputBox);

        // Close button
        Button closeButton = new Button("Close");
        closeButton.setOnAction(e -> messageStage.close());
        layout.getChildren().add(closeButton);

        Scene scene = new Scene(layout, 600, 400);
        messageStage.setScene(scene);
        messageStage.show();
    }

    // Refresh the ListView with messages from the DB
    private void refreshMessageList(ListView<Message> listView) {
        List<Message> messages = reviewManager.getMessagesForReview(review.getId());
        ObservableList<Message> observableList = FXCollections.observableArrayList(messages);
        listView.setItems(observableList);
        listView.setCellFactory(param -> new ListCell<Message>() {
            @Override
            protected void updateItem(Message item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    // Example display: "sender: content"
                    setText(item.getSender() + ": " + item.getContent());
                }
            }
        });
    }
}

package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Pair;

import java.util.List;
import java.util.Map;

public class StaffHomePage extends Application {

    private ReviewManager reviewManager = new ReviewManager();

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Staff Dashboard");

        Button viewUsersBtn = new Button("View All Users");
        Button deleteReviewBtn = new Button("Delete Review by ID");
        Button changeRoleBtn = new Button("Change User Role");
        Button viewFlaggedBtn = new Button("View Flagged Reviews");
        Button usageReportBtn = new Button("Generate Usage Report");

        // View All Users
        viewUsersBtn.setOnAction(e -> {
            List<User> users = reviewManager.getAllUsers();
            users.forEach(u -> System.out.println(u.getId() + " - " + u.getUsername() + " - " + u.getRole()));
        });

        // Delete Review by ID
        deleteReviewBtn.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setHeaderText("Enter Review ID to Delete:");
            dialog.showAndWait().ifPresent(id -> {
                try {
                    boolean success = reviewManager.deleteReviewById(Integer.parseInt(id));
                    System.out.println(success ? "Review Deleted" : "Deletion Failed");
                } catch (NumberFormatException ex) {
                    System.out.println("Invalid ID format.");
                }
            });
        });

        // Change User Role
        changeRoleBtn.setOnAction(e -> {
            Dialog<Pair<String, String>> dialog = new Dialog<>();
            dialog.setTitle("Change User Role");

            TextField userId = new TextField();
            TextField newRole = new TextField();
            VBox content = new VBox(new Label("User ID:"), userId, new Label("New Role:"), newRole);
            dialog.getDialogPane().setContent(content);
            dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);

            dialog.setResultConverter(btn -> new Pair<>(userId.getText(), newRole.getText()));
            dialog.showAndWait().ifPresent(pair -> {
                try {
                    int id = Integer.parseInt(pair.getKey());
                    boolean success = reviewManager.updateUserRole(id, pair.getValue());
                    System.out.println(success ? "Role updated." : "Failed to update role.");
                } catch (NumberFormatException ex) {
                    System.out.println("Invalid User ID.");
                }
            });
        });

        // View Flagged Reviews
        viewFlaggedBtn.setOnAction(e -> {
            List<Review> flagged = reviewManager.getFlaggedReviews();
            flagged.forEach(r -> System.out.println("ID: " + r.getId() + ", Text: " + r.getReviewText()));
        });

       
    }
}
